from tkinter import messagebox
import tkinter.filedialog as fd
from cryptography.fernet import Fernet

class Crypt:
    def __init__(self, key=None, create_key=False):
        self.__fernet = None
        if create_key:
            self.__key = Fernet.generate_key()
        else:
            if key is not None:
                self.__key = key
            else:
                raise ValueError("Error: initializing without key")
        self.__fernet = Fernet(self.__key)
        self.__fname = None

    @property
    def key(self):
        return self.__key

    def encrypt(self, data:str) -> bytes:
        if self.__fernet:
            return self.__fernet.encrypt(bytes(data, encoding='ascii'))
        return None
    
    def decrypt(self, data) -> str:
        if self.__fernet:
            decrypted_data = self.__fernet.decrypt(data)
            return str(decrypted_data, encoding='ascii')
        return ""

    def LoadKeyFile(self, dialog=False, fname=None, title=None, ftype = None) ->str:
        """LoadKeyFile
        load configuration from key file and return loaded contents as string
        encoding: ascii

        Args:
            parent (widget): parent widget of dialog of opening file name
            title (str): title of dialog
            keyfile (path, optional): path name to be opened file. Defaults to None and open a dialog.

        Returns:
            str: content of file as a string
        """
        if dialog:
            if ftype is None:
                ftype = ("*", "*")       
            self.__fname = fd.askopenfilename(filetypes=(ftype, ("All files", "*.*")),
                                        initialdir='.', 
                                        title=title)
        else:
            if self.__fname is None:
                raise ValueError("Error: no file name")
            
        with open(self.__fname, 'rb') as f:
            encrypted_data = f.readline()
        return self.decrypt(encrypted_data)

    def WriteKeyFile(self, data, dialog=False, fname=None, title=None, ftype = None):
        """WriteKeyFile
        write encrypted content into key file

        Args:
            parent (widget): parent widget of dialog of opening file name
            title (str): title of dialog
            data (str): content to be written
            initfile (_type_, optional): path name of file to be written to. Defaults to None and open a dialog.
        """
        if dialog: 
            if ftype is None:
                ftype = ("*", "*")       
            self.__fname = fd.asksaveasfilename(filetypes=(ftype, ("All files", "*.*")),
                                        title=title,
                                        confirmoverwrite=True)
        else:
            if self.__fname is None:
                raise ValueError("Error: no file name")
            
        print(f"File name: {fname}")
        encrypted_data = self.encrypt(data)
        with open(self.__fname, 'wb') as f:
            f.write(encrypted_data)


if __name__ == "__main__":
    crypt_text = 'This is text'
    crypt = Crypt(create_key=True)
    crypt.WriteKeyFile(crypt_text, dialog=True)
    text = crypt.LoadKeyFile()
    if text == crypt_text:
        print("Crypting text is successful")
    text = crypt.LoadKeyFile(dialog=True)
    if text == crypt_text:
        print("Crypting text is successful with dialog")
    
