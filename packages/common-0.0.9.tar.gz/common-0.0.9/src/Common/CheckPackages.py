import sys
import subprocess
import pkg_resources
from pkg_resources import DistributionNotFound, VersionConflict

def should_install_requirement(requirement):
    should_install = False
    try:
        pkg_resources.require(requirement)
    except (DistributionNotFound, VersionConflict):
        should_install = True
    return should_install


def install_packages(requirement_list):
    try:
        ## update pip
        subprocess.run('python -m pip install --upgrade pip')
        if len(requirement_list) == 0:
            return True
        requirements = [
            requirement
            for requirement in requirement_list
            if should_install_requirement(requirement)
        ]
        if len(requirements) > 0:
            subprocess.check_call([sys.executable, "-m", "pip", "install", *requirements])
        else:
            print("Requirements already satisfied.")
            return True
    except Exception as e:
        print(type(e))
        print(e)
        return False
    
if __name__ == '__main__':
    install_packages(['tkcalendar', 'reportlab'])