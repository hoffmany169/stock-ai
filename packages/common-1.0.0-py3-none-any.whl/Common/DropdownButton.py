import tkinter as tk


class DropdownButton(tk.OptionMenu):
    def __init__(self, master, options, default="Select...", command=None, **kwargs):
        self.var = tk.StringVar(value=default)
        self.command = command

        super().__init__(
            master,
            self.var,
            *options,
            command=self._on_select,
            **kwargs
        )

        self.config(relief="raised")

    def _on_select(self, value):
        if self.command:
            self.command(value)

    def get(self):
        return self.var.get()

    def set(self, value):
        self.var.set(value)

if __name__ == "__main__":
    """test codes"""
    root = tk.Tk()

    dropdown = DropdownButton(
        root,
        ["Apple", "Banana", "Cherry", "Date"],
        command=lambda x: print ("Selected ", x)
    )
    dropdown.pack(padx=20, pady=20)

    root.mainloop()
