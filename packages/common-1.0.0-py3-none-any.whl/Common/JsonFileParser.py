from tkinter import *
import json, os, sys
from Common.Util import GetResourcePathName, GetResource

class JsonFileParser:
    def __init__(self, fname) -> None:
        self._json_file = None
        self._contents = {}
        if fname is not None:
            self.LoadJsonResource(fname)

    @property
    def Contents(self) -> dict:
        return self._contents

    @property
    def Keys(self) -> list:
        if len(self._contents) == 0:
            return []
        return self._contents.keys()

    @property
    def Values(self) -> list:
        if len(self._contents) == 0:
            return []
        return self._contents.values()

    def InitContents(self, keys:list, valtype:type):
        for k in keys:
            if valtype == list:
                self._contents[k] = []
            elif valtype == set:
                self._contents[k] = ()
            else:
                self._contents[k] = None

    def LoadJsonResource(self, fname, create=True):
        if fname is None:
            raise ValueError("Error: Name of Json file is None!")
        self._json_file = GetResourcePathName('.', fname)
        if not os.path.exists(self._json_file):
            if create:
                with open(self._json_file, "x") as f:
                    self._contents = {}
            else:
                self._json_file = None
                raise FileExistsError(f"Error: {fname} is not found!")
        else:
            try:
                if os.path.getsize(self._json_file) == 0:
                    print(f"File [{self._json_file}] is empty")
                    self._contents = {}
                    return
                with open(self._json_file, "r") as f:
                    self._contents = json.load(f)
            except IOError:
                self._json_file = None
                raise IOError(f"Error: cannot open [{fname}] to read!")

    def SaveJsonResource(self):
        if self._contents is None or type(self._contents) != dict:
            raise TypeError("Resource data for JSON is not valid")
        with open(self._json_file, 'w') as f:
            json.dump(self._contents, f)
        
    def SetValue(self, key, value, overwrite=True):
        '''SetValue
        set value by key. 
        if type of value in contents is list, new value will overwrite value in list by default. Otherwise new value is appended at end of list
        key: key of value
        value: new value to be set.
        overwrite: if set, value under key will be overwritten by default. if overwrite is False, new value is added at end of list. this parameter is valid only for list.
        '''
        if key in self._contents:
            if type(self._contents[key]) == list:
                if overwrite:
                    self._contents[key].clear()
                if value not in self._contents[key]:
                    self._contents[key].append(value)
            elif type(self._contents[key]) == set:
                if overwrite:
                    self._contents[key].clear()
                if value not in self._contents[key]:
                    self._contents[key].add(value)
            else:
                self._contents[key] = value
            
    def GetValue(self, key):
        if key in self._contents:
            return self._contents[key]
        return None
    
    def AddItem(self, value):
        '''AddItem
        add a new item into contents. 
        if value is set or list, the first value is treated as key and the second value is treated as value.
        if value is dict, it will be added simply.
        '''
        if type(value) == set or type(value) == list:
            self._contents[value[0]] = value[1]
        elif type(value) == dict:
            self._contents.update(value)
        else:
            raise ValueError("Error: type of value is not supported!")

    def AddItems(self, values):
        if type(values) == list:
            for item in values:
                self.AddItem(item)
        elif type(values) == dict:
            self._contents.update(values)
        else:
            raise ValueError("Error: values must be list or dict")