import pickle

class Originator:
    """class Originator
    create a memento containing a snapshot of its current internal data
    Use the memento to restore its internal data
    """
    DATA_TYPE = ['List', 'Dict']
    _data = None
    def __init__(self, datatype) -> None:
        """constructor

        Args:
            datatype (int or str): index of type list or text:\n
            DATA_TYPE = ['List', 'Dict'] 
        """
        find = None
        if type(datatype) == str:
            if datatype in self.DATA_TYPE:
                find = self.DATA_TYPE.index(datatype)
        elif type(datatype) == int:
            if datatype >= 0 and datatype < len(self.DATA_TYPE):
                find = datatype
        if find is None:
            self._data = None
        else:
            if find == 0:
                self._data = []
            elif find == 1:
                self._data = {}
    
    @property
    def Data(self):
        return self._data
    
    @property
    def DataCounter(self):
        return len(self._data)
                
    def AddEntry(self, value, key=None):
        if type(self._data) == list:
            self._data.append(value)
        elif type(self._data) == dict:
            if key is None:
                raise TypeError('key of entry is None')
            self._data[key] = value
        else:
            raise TypeError('Undefined data type of originator')
        
    def GetValue(self, key):
        if type(self._data) == list:
            if type(key) == int and key >= 0 and key < len(self._data):
                return self._data[key]
        elif type(self._data) == dict:
            if key in self._data:
                return self._data[key]
        return None
        
    def RecoverData(self, data):
        prev_data = pickle.loads(data)
        vars(self).clear()
        vars(self).update(prev_data)
        
    def CreateMemento(self):
        return pickle.dumps(vars(self))
    
    def ClearData(self):
        self._data.clear()
