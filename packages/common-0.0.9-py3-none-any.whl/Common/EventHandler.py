from Common.AutoNumber import AutoIndex
from Common.Singleton import Singleton

class SykamEvent:
    """
    SykamEvent
    top class for event handler
    param[evt] AutoIndex or str, used to point to its handler function
    param[handler] corresponding handler function of event
    param[*args] parameters of handler function if it has
    """
    def __init__(self, evt:AutoIndex|str=None, handler=None, *args):
        self._Event = evt
        self._Handler = handler
        self._params = args

    @property
    def Event(self):
        return self._Event
    
    @Event.setter
    def Event(self, evt:AutoIndex):
        self._Event = evt

    @property
    def Handler(self):
        return self._Handler
    
    @Handler.setter
    def Handler(self, hdl):
        self._Handler = hdl

class EventHandler(Singleton):
    """ EventHandler
    this class is used to define events and their handler in a list, whose items are tuples.
    It is a singleton class. It means it points always to the same instance however it is called
    """
    __envent_handler = None # event dictionary
    def __init__(self):
        if self.__envent_handler is None:
            self.__envent_handler = {}

    @property
    def total_event_number(self):
        ## total number of events in the event dictionary
        return len(self.__envent_handler)
    
    def get_handler_function(self, evt:AutoIndex|str):
        '''
        get_handler_function
        return the handler function corresponding the event
        '''
        if evt in self.__envent_handler:
            return self.__envent_handler[evt]
        return None

    def clear_events(self):
        self.__envent_handler.clear()

    def __iadd__(self, evt:SykamEvent):
        '''operator +=
        add event into event dictionary
        param[evt] object of SykamEvent
        '''
        if evt is None:
            raise ValueError("Event object is None!")
        if evt.Event in self.__envent_handler:
            print (f"Event Id[{evt.Event.name}] exists already!")
            return
        self.__envent_handler[evt.Event] = evt.Handler
        return self
    
    def __isub__(self, param):
        '''operator -=
        remove an event from event dictionary
        param[param] event object or string, or handler object
        '''
        for evt, handler in self.__envent_handler.items():
            if evt == param or handler == param:
                self.__envent_handler.pop(evt)
                break
        return self
    
    def __call__(self, event, *args, **kwargs):
        '''operator () to call function
        call handler function by event
        '''
        if event == None:
            raise ValueError("Event of handler is None!")
        if event not in self.__envent_handler:
            raise ValueError("Invalid event!")
        for evt, handler in self.__envent_handler.items():
            if evt == event: 
                handler(*args, **kwargs)
                break

