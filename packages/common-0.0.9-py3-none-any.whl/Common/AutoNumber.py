from enum import *

class NoValue(Enum):
    def __repr__(self) -> str:
        return '<%s.%s>' % (self.__class__.__name__, self.name)
    
class AutoNumber(NoValue):
    """class AutoNumber
    simulate enumerator just like that in C/C++

    Args:
        NoValue (Enum): _description_
    """
    def __new__(cls, *args):
        value = len(cls.__members__) + 1
        obj = object.__new__(cls)
        obj._value_ = value
        return obj
    
class AutoIndex(NoValue):
    """class AutoIndex
    simulate enumerator just like that in C/C++

    Args:
        NoValue (Enum): _description_
    """
    def __new__(cls, *args):
        value = len(cls.__members__)
        obj = object.__new__(cls)
        obj._value_ = value
        return obj

### Test codes #####    
class KeyData(AutoIndex):
    # def __init__(self, idx=0):
    #     self.index = idx
    DEV_ID = ()
    SER_NUM = ()
    OPTIONS = ()

_MEMBER = ['Test1', 'Test2']
class TestAutoNumber(AutoNumber):
    """TestAutoNumber
    implement initializing enumerators by a list
    """
    exec(f"{_MEMBER[0]} = ()") 
    exec(f"{_MEMBER[1]} = ()") 
            
if __name__ == '__main__':
    index = 0
    print("--- AutoNumber ---")
    for i in TestAutoNumber:
        print(f"Array _MEMBER[{index}]: {_MEMBER[index]}")
        print(f"{i}.name({i.name}) = {i.value}({i}.value) (type: {type(i.value)})")
        index += 1
    print("--- AutoIndex ---")
    for i in KeyData:
        print(f"{i}.name({i.name}) = {i.value}({i}.value) (type: {type(i.value)})")
