from threading import Lock
from tkinter import *
from tkinter import messagebox
from tkinter import ttk
from time import *

G_EventTimer = None
class EventTimer:    
    """@class EventTimer
        define a timer for events. if timeout the callback will be called
        the event timer will be deleted after used.
    """
    class Progressbar:
        """@class Progressbar
            an inner class to define a graphic progressbar
        """
        def __init__(self, outer, parent, title) -> None:
            self.top = Toplevel(parent)
            self.top.transient(parent)
            self.top.grab_set()
            self.top.title(title)
            ## graphic elements
            self.prgbar = ttk.Progressbar(self.top, orient='horizontal', mode='determinate', length=280)
            self.prgbar.grid(row=0, column=0, padx=20)
            self.label = Label(self.top, text=self._UpdateProgressbar)
            self.label.grid(row=1, column=0, padx=20, pady=20)
            ## instance of outer class: Progressbar
            self._outerinstance = outer
            
        def _UpdateProgressbar(self):
            curval = float(self._outerinstance._currentvalue - self._outerinstance._start) / self._outerinstance._end * 100.0
            self.prgbar['value'] = curval
            return "Current Time: {:.2f}%".format(curval)
            
        def Progress(self, isend):
            if isend:
                self.label['text'] = 'The progress completed'
            else:
                self.label['text'] = self._UpdateProgressbar()
             
        def Destroy(self):
            self.top.destroy()
        
    def __init__(self, seconds, cb=None) -> None:
        self._start = 0.0
        self._end = seconds
        self.callback = None  
        self._started = False
        self._currentvalue = 0.0
        self._progressbar = None
        self._mutex = Lock()
    
    def __del__(self):
        del self._mutex
        if self._progressbar:
            del self._progressbar
            
    @property
    def Timeout(self, sec):
        """set timeout time (seconds)"""
        self._end = sec
         
    @property
    def Started(self):
        return self._started
    
    def AddProgressbar(self, parent, title):
        self._progressbar = self.Progressbar(self, parent, title)
        
    @property
    def Callback(self):
        """Callback
            if timer is end, call this callback
        Returns:
            function: callback function if timer reaches end
        """
        return self.callback
    
    @Callback.setter
    def Callback(self, cb):
        self.callback = cb
    
    def Start(self):
        """@function Start
            start event timer
        """
        self._start = time() 
        self._started = True
        
    def Cancel(self):
        """@function Cancel
            stop timer and set progressbar to 100%       
        """
        self._start = 0.0
        self._started = False
        self._currentvalue = self._end
        if self._progressbar:
            self._progressbar.label['text'] = self._progressbar._UpdateProgressbar()
        
    def DestroyProgressbar(self):
        if self._progressbar is not None:
            self._progressbar.Destroy()
        
    def CheckTimeout(self)->bool:
        """@function CheckTimeout
            checking if timeout
        """
        if self._started:
            self._mutex.acquire()
            self._currentvalue = time()
            isend =  self._end <= (self._currentvalue - self._start)
            if isend:
                """end timer"""
                self._started = False                
                if self._progressbar is not None:
                    self._progressbar.Destroy()
                if self.callback is not None:
                    self.callback()
                return True
            else:
                if self._progressbar is not None:
                    self._progressbar.Progress(isend)
            self._mutex.release()
        return False

"""
    assistant functions
    Usage:
    1. CreateEventTimer(): with or without callback function to be set
    2. SetCallback(): option - if callback is not set at first step
    3. WithProgressbar(): option - create progressbar
    3. StartEventTimer(): start timer
    4. Timeout(): check if timeout is reaching
    5. CancelEventTimer(): stop timer and show progressbar as 100% if it is available
    6. DestroyEventTimer(): destroy timer
    
"""        
def CreateEventTimer(seconds, cb=None):
    """@method CreateEventTimer
        create instance of EventTimer. apply singleton pattern
    Args:
        seconds (float): time of timeout
        cb (function, optional): callback function.
    """
    global G_EventTimer
    if G_EventTimer is None:
        G_EventTimer = EventTimer(seconds, cb)

def WithProgressbar(parent, title='Timer'):
    """@method WithProgressbar
        add graphic progressbar to event timer
    Args:
        parent (window): parent of progressbar
        title (str, optional): title of progressbar, defaut is 'Timer'.
    """
    global G_EventTimer
    G_EventTimer.AddProgressbar(parent, title)
    
def SetCallback(cb):
    """@method SetCallback
        set callback function for event timer if timeout 
    Args:
        cb (function): 
    """
    global G_EventTimer
    G_EventTimer.Callback = cb
    
def Timeout():
    """@method Timeout
        check if event timer is timeout
    Returns:
        bool: True or False
    """
    global G_EventTimer
    if G_EventTimer is None:
        return False
    if G_EventTimer.CheckTimeout():
        del G_EventTimer
        G_EventTimer = None
        return True
    return False

def EventTimerStarted():
    """GetEventTimerState
        get the state of event timer
    Returns:
        any: True - Event timer is started
             False - Event timer is stopped
             None - instance of EventTimer is deleted
    """
    global G_EventTimer
    if G_EventTimer:
        return G_EventTimer.Started
    return None

def StartEventTimer():
    """@method StartEventTimer
        wrap function of starting event timer    
    """
    global G_EventTimer
    if G_EventTimer:
        G_EventTimer.Start()
    
def CancelEventTimer():
    """@method CancelEventTimer
        wrap function of cancelling event timer    
    """
    global G_EventTimer
    if EventTimerStarted():
        G_EventTimer.Cancel()

def DestroyEventTimer():
    global G_EventTimer
    if EventTimerStarted() == True:
        G_EventTimer.Cancel()
    if G_EventTimer: 
        G_EventTimer.DestroyProgressbar()       
        del G_EventTimer
        G_EventTimer = None
        