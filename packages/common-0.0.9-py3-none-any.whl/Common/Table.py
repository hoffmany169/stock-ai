from tkinter import EW, Frame, Label, Tk

class Column:
    def __init__(self, parent, col, bg_color=None) -> None:
        self._index = col
        if bg_color:
            self._label = Label(parent, background=bg_color)
        else:
            self._label = Label(parent)
        self._label.grid(row=0, column=col)

    @property
    def Index(self):
        return self._index
        
    @property
    def Label(self):
        return self._label

    @property
    def Width(self):
        return self._label.config(width=None)
    @Width.setter
    def Width(self, w):
        self._label.config(width=w)
        
    @property
    def Text(self):
        return self._label['text']
    @Text.setter
    def Text(self, t):
        self._label['text'] = t
        
    @property
    def Padx(self):
        return self._label.config(padx=None)
    @Padx.setter
    def Padx(self, x):
        self._label.configure(padx=x)
        
    @property
    def Pady(self):
        return self._label.config(pady=None)
    @Padx.setter
    def Pady(self, y):
        self._label.configure(padx=y)
        
class Row:
    def __init__(self, parent, idx, col, has_frame=True) -> None:
        self._index = idx
        self._bg_color = None
        if has_frame == False:
            if self._index % 2:
                self._bg_color = 'white'
        self._col = col
        self._columns = []
        if has_frame:
            self._Frame = Frame(parent, highlightthickness=1, highlightbackground='black')
        else:
            self._Frame = Frame(parent)
        self._Frame.grid(row=idx, columnspan=self._col, sticky=EW)

    @property
    def Index(self):
        return self._index
        
    @property
    def Padx(self):
        return self._Frame.config(padx=None)
    @Padx.setter
    def Padx(self, x):
        self._Frame.configure(padx=x)
        
    @property
    def Pady(self):
        return self._Frame.config(pady=None)
    @Pady.setter
    def Pady(self, y):
        self._Frame.configure(pady=y)
    
    @property
    def Background(self):
        return self._Frame.config(bg=None)
    @Pady.setter
    def Pady(self, b):
        self._Frame.configure(bg=b)
    
    def AddColumn(self, col=0, font=None):
        """AddColumn 

        Args:
            col (int, optional): index of column. Defaults to 0.
            font (Font, optional): font to be set. Defaults to None.
        """
        cur_col = Column(self._Frame, col, self._bg_color)
        if font:
            cur_col.Label.config(font=font)
        self._columns.append(cur_col) 

    def AddColumns(self, font=None):
        """AddColumns

        Args:
            row (int): index of row
            font (Font, optional): font to be set. Defaults to None.

        Returns:
            Row: object of Row
        """
        for col in range(0, self._col):
            self.AddColumn(col, font) 
        return self
    
    def GetColumn(self, index):
        return self._columns[index]
    
    def SetColumnContents(self, contents):
        """SetColumnContents

        Args:
            contents (list or dict): texts of content

        Raises:
            Exception: only list or dict data is dealed with, otherwise raise exception
        """
        content_list = None
        if type(contents) == dict:
            content_list = list(contents.values())
        elif type(contents) == list:
            content_list = contents
        else:
            raise Exception("Type Error", "Parameter must be a list")
        for i in range(0, self._col):
            # self.SetColumnText(i, contents[i])
            self._columns[i].Text = content_list[i]

    def SetColumnText(self, index, text):
        self._columns[index].Text = text

class Table:
    def __init__(self, parent, head_row, row, col, has_frame=True, start_row=0) -> None:
        """Table construct
        implement table for list.
        Args:
            parent (widget): parent widget of table
            head_row (int): number of header row
            row (int): number of total rows of contents
            col (int): number of total columns
            has_frame (bool, optional): True for using frame lines for table; otherwise using background color. Defaults to True.
            start_row (int): index of row of table frame in whole widget. Defaults to 0
        """
        self._head_row = head_row
        self._row = row
        self._col = col
        self._has_frame = has_frame
        self._rows = []
        self._table = Frame(parent, background='white')
        self._table.grid(row=start_row, rowspan=self._row + self._head_row, columnspan=self._col)

    @property
    def Frame(self):
        return self._table

    @property
    def ColumnNum(self):
        return self._col
    @property
    def HeadColNum(self):
        return self._head_row

    @property
    def RowNum(self):
        return self._row

    @property
    def ColumnNum(self):
        return self._col
        
    @property
    def HasFrame(self):
        return self._has_frame
    @HasFrame.setter
    def HasFrame(self, yes):
        self._has_frame = yes

    def GetRow(self, index):
        return self._rows[index]

    def CreateHeaderRow(self, contents, font=None):
        """CreateHeaderRow

        Args:
            contents (list): contents of header row
            font (Font): font of header row. Defaults to None
        Raises:
            Exception: type of contents must be list
        """
        if type(contents) != list:
            raise Exception("Error", "Contents of header must be list")
        for r in range(0, self._head_row):
            self._rows.append(Row(self._table, 0, self._col, self._has_frame))
            self._rows[r].AddColumns(font).SetColumnContents(contents)

    def CreateTableBody(self):
        """CreateTableBody

        Raises:
            Exception: call this function after CreateHeaderRow
        """
        if len(self._rows) != self._head_row:
            raise Exception("Error", "The header row was not created, yet")
        for r in range(self._head_row, self._row + self._head_row):
            row = Row(self._table, r, self._col, self._has_frame)
            row.AddColumns()
            self._rows.append(row)

    def FillRowContents(self, row, contents):
        self._rows[row].SetColumnContents(contents)
        
    def FillBodyRows(self, contents):
        """FillBodyRows
        fill body according to rows
        Args:
            contents (list): texts list to fill table

        Raises:
            Exception: type of contents must be list
        """
        if type(contents) != list:
            raise Exception("Error", "Contents must be list")
        for r in range(self._head_row, self._head_row + self._row):
            item = contents[r-self._head_row]
            ## fill all columns at row r
            self.FillRowContents(r, item)
    
    def FillColumnContents(self, col, contents):
        for r in range(self._head_row, self._head_row + self._row):
            self._rows[r].SetColumnText(col, contents[r-self._head_row])

    def FillBodyColumns(self, contents):
        """FillBodyColumns
        fill body according to columns
        Args:
            contents (list): texts list to fill table

        Raises:
            Exception: type of contents must be list
        """
        if type(contents) != list:
            raise Exception("Error", "Contents must be list")
        for c in range(0, self._col):
            item = contents[c]
            ## fill all rows in column c
            self.FillColumnContents(c, item)    
        
    def Update(self):
        self._table.update()
    
    def SetColumnAlignment(self, col_idx, side, row_idx=None, no_row=None):
        """SetColumnAlignment

        Args:
            col_idx (int): index of column to be set
            side (str): W, E
            row_idx (int): index of row, in which col_idx will be set. Defaults to None
            no_row (int): index of row, in which col_idx will not be set. Defaults to None
        """
        idx = 0
        for row in self._rows:
            if row_idx !=None and idx == row_idx:
                col = row.GetColumn(col_idx)
                col.Label.config(anchor=side)
                break
            if no_row != None and idx != no_row:
                col = row.GetColumn(col_idx)
                col.Label.config(anchor=side)
            if row_idx == None and no_row == None:                
                col = row.GetColumn(col_idx)
                col.Label.config(anchor=side)
            idx += 1

    def SetColumnWidth(self, col_idx, w):
        for row in self._rows:
            col = row.GetColumn(col_idx)
            col.Label.config(width=w)
        
## test codes
if __name__ == '__main__':
    Contents = [['name 1', '25'],
                ['name 2', '32'],
                ['name 3', '64']]
    root = Tk()
    table = Table(root, 1, 3, 2)
    table.CreateHeaderRow(['name', 'year'])
    table.CreateTableBody()
    for l in range(0, len(Contents)):
        table.FillRowContents(l, Contents[l])
    root.mainloop()