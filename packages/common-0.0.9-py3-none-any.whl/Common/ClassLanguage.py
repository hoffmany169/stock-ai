import os, sys
from tkinter import messagebox
import argparse
import json
## run this module from other applications
from Common.Singleton import Singleton

"""ClassLanguage.py
create class Language for multiple language application dynamically.
The following files must be supplied for the class:
- LanguageIds.txt: define IDs for texts in the applications. This is the default name.
- Lang.xx: define texts corresponding to the language ids for different languages. xx: language code, for example: en for english, de for deutsch
== Usage:
class:              Language
constructor:        constructor(self, pathname) # pname: path-name of language table
class members:      __LANG_TEXT, __LANG_ID_FILE, __LANG_FILE, _LANG_BASE_NAME
properties:         LanguageName, LanguageCode, LanguageLoaded
member functions:   SetCallback(), LoadLanguageIDs(), UnloadLanguageData(), UpdateLanguage(), 
                    GetText(), ShowLangText(), SetLanguageFilePath(), SetLanguageIDFileName()
conditions:
1. from Common.ClassLanguage import *
2. create language table: includes all pairs of {language_code : language_name}
3. create text file of language IDs
4. create text files of language texts for each language
Steps:
1. create instance: lang = Language("test", "de")
2. if name of language id is not default, set it: lang.SetLanguageIDFileName(fname, path)
3. if name of language text is not default, set it: lang.SetLanguageFilePath(path, basename, languagecode)
4. load language data: lang.LoadLanguageIDs()
"""
## default language table
LANG_TABLE = {"de": "Deutsch", "en" : "English"}

class LanguageTableFileNoneError(FileExistsError):
    def __init__(self):
        super().__init__(f"Language Table file is None")

def constructor(self, pathname=None, langfilepath=None, langidfile=None, langcode=None):
    """pathname: path-name of language table.
    if a instance is already exits, the instance can be gotten without argument "pathname"
    """
    if pathname is not None:
        self.__LANG_TABLE_FILE = pathname
        if not os.path.exists(self.__LANG_TABLE_FILE):
            ## create a default language table
            print("Creating default language table file ...")
            self.CreateLanguageTableFile(self.__LANG_TABLE_FILE)
        with open(self.__LANG_TABLE_FILE, "r") as lang_table:
            self.__LANG_TABLE = json.load(lang_table)
        ## get a guess language file path
        self.__LANG_FPATH = os.path.split(pathname)[0]
        ## default settings for language data
        if langfilepath is None:
            if len(self.__LANG_FPATH) == 0:
                self.__LANG_FPATH = './Language'
        else:
            self.__LANG_FPATH = langfilepath
        self.__LANG_ID_FILE = 'Lang.id' if langidfile is None else langidfile
        self._LANG_BASE_NAME = 'lang'
        ## set current language as the 1st item in language table
        self.__CODE = list(self.__LANG_TABLE)[0] if langcode is None else langcode
        self.__LANG_NAME = self.__LANG_TABLE[self.__CODE]
        self.__cb = None
        self.__LANG_FILE = os.path.join(self.__LANG_FPATH, f"{self._LANG_BASE_NAME}.{self.__CODE}")
    else:
        if self.__loaded is False:
            ## default settings for language data
            self.__LANG_TABLE_FILE = None
            self.__LANG_FPATH = './Language'
            self.__LANG_ID_FILE = 'Lang.id'
            self._LANG_BASE_NAME = 'lang'
            self.__CODE = 'en'
            self.__LANG_NAME = 'English'
            self.__LANG_FILE = 'lang.en'

@property
def LanguageTableFile(self):
    return self.__LANG_TABLE_FILE

@property
def LanguageFilePath(self):
    return self.__LANG_FPATH

@property
def LanguageIdFile(self):
    return self.__LANG_ID_FILE

@LanguageIdFile.setter
def LanguageIdFile(self, fname):
    self.__LANG_ID_FILE = fname

@property
def LanguageBaseName(self):
    return self._LANG_BASE_NAME

@property
def LanguageName(self):
    return self.__LANG_NAME

@property
def LanguageCode(self):
    return self.__CODE

def _LoadLanguageTableFile(self):
    if self.__LANG_TABLE_FILE is None:
        return
    try:
        with open(self.__LANG_TABLE_FILE, "r") as lang_table:
            self.__LANG_TABLE = json.load(lang_table)
    except IOError:
        raise IOError("Error: Cannot load language table file!")

def _LoadLanguageIDFile(self) -> list[str]:
    if self.__LANG_ID_FILE is None:
        raise ValueError("Error: language id file is None")
    # load language ids
    fname = os.path.join(self.__LANG_FPATH, self.__LANG_ID_FILE)
    if os.path.exists(fname):
        with open(fname, encoding='utf-16') as f:
            return f.readlines()
    else:
        raise FileExistsError("Error",
                        f"Language ID file is not found![{fname}]")

def _LoadLanguageFile(self) -> list[str]:
    if self.__LANG_FILE is None:
        raise ValueError("Error: language file is None")
    texts = []
    if os.path.exists(self.__LANG_FILE):
        with open(self.__LANG_FILE, encoding='utf-16') as f:
            texts = f.readlines()
    else:
        messagebox.showerror("ERROR", 'Language file is not found !')
    return texts

def _LoadLanguageTexts(self, cb=None):
    """merge language IDS with language file as dict for usage
    """
    if self.__LANG_NAME is None:
        print("Invalid language name or code")
        return
    if self.__CODE is None:
        self.__CODE = 'en' # set default language code
    if cb is not None:
        self.__cb = cb

    keys = self._LoadLanguageIDFile()
    texts = self._LoadLanguageFile()
    if len(keys) != len(texts):
        messagebox.showerror("ERROR", "IDs don't match loaded language texts !")
        return
    if len(self.__LANG_TEXT) > 0:
        self.UnloadLanguageData()
    for idx in range(0, len(keys)):
        self.__LANG_TEXT[keys[idx].strip()] = texts[idx].strip()
    self.__loaded = True
    if self.__cb is not None:
        self.__cb()

def _UnloadLanguageData(self):
    if self.__loaded:
        self.__LANG_TEXT.clear()
        self.__loaded = False

def _UpdateLanguage(self, code=None, name=None, cb=None):
    """UpdateLanguage data if language is changed
    param[code] str: code of language. it should not be None if name is None
    param[name] str: name of language. it should not be None if code is None
    param[cb] function: callback function after language is updated
    """
    if code is None and name is None:
        return False
    if code is not None:
        if code in self.__LANG_TABLE:
            if self.__CODE == code:
                return True
            self.__CODE = code
            self.__LANG_NAME = self.__LANG_TABLE[self.__CODE]
        else:
            raise ValueError(f"Error: language code {code} is not supported")
    elif name is not None:
        if name == self.__LANG_NAME:
            return True
        if name in self.__LANG_TABLE.values():
            self.__LANG_NAME = name
            for c, n in self.__LANG_TABLE.items():
                if n == name:
                    self.__CODE = c
                    break
        else:
            raise ValueError(f"Error: language code {name} is not supported")
    else:
        raise ValueError(f"Error: language code or name must be specified!")
    self.__cb = cb
    self.SetLanguageFileName(self.__LANG_FPATH, self._LANG_BASE_NAME, self.__CODE)
    self.LoadLanguageTexts()
    return True

def _ShowFileTexts(self, contents):
    """ShowLangText
    display all texts from current language
    """
    if type(contents) == list:
        if len(contents) == 0:
            print("The file is empty!")
            return
        for entry in contents:
            print(entry)
    else:
        if len(list(contents)) == 0:
            print("The file is empty!")
            return
        for entry in contents:
            print(f"{entry} -> {contents[entry]}")

def _SetLanguageFileName(self, path=None, basename=None, langcode=None):
    if path is None:
        path = '.'
    self.__LANG_FPATH = os.path.abspath(path)    
    if basename is not None:
        self._LANG_BASE_NAME = basename
    if langcode is not None:
        self.__CODE = langcode
    if self.__CODE in self.__LANG_TABLE:
        self.__LANG_NAME = self.__LANG_TABLE[self.__CODE]
    else:
        raise ValueError(f'Error: language code [{self.__CODE}] is not found in language table')
    
    self.__LANG_FILE = os.path.join(self.__LANG_FPATH, f"{self._LANG_BASE_NAME}.{self.__CODE}")
    return self

def _GetText(self, id) -> str:
    try:
        text = self.__LANG_TEXT[id]
    except KeyError:
        return "Unknown"
    else:
        return text

def _SetCallback(self, cb):
    if cb is not None:
        self.__cb = cb

@staticmethod
def _CreateLanguageTableFile(name="lang_table.json", lang_codes=list(LANG_TABLE)):
    lang_table = {}
    for l in lang_codes:
        if l in LANG_TABLE:
            lang_table[l] = LANG_TABLE[l]
        else: 
            raise ValueError(f"Error: language code {l} is not supported.")
    with open(name, 'w') as f:
        json.dump(lang_table, f)

## module Singleton depends the system path
""" class Language(Singleton)
Constructor
- Language(pathname=None): 
  + pathname: path-name of language table file (json), in which the supported languages are defined

Static function
- CreateLanguageTableFile(name="lang_table.json", lang_codes=list(LANG_TABLE)): create language table file
  + name: name of language table file, default: lang_table.json
  + lang_codes: list of supported language codes, default: predefined LANG_TABLE

Properties
- LanguageTableFile (getter, setter): path + file name
- LanguageFilePath (getter): path for language id file and language files
- LanguageIdFile (getter): only file name without path, which is specified in LanguageFilePath, full path-name is LanguageFilePath + LanguageIdFile
- LanguageBaseName (getter): full path-name is LanguageFilePath + LanguageBaseName + LanguageCode
- LanguageCode (getter)
- LanguageName (getter, setter)

Interface functions
- SetLanguageFileName(path=None, basename=None, langcode=None): initialize or change path of language files, basename or language code
- SetLanguageIDFileName(fname): deprecated, use property instead
- LoadLanguageTexts(): load complete table (dict) for the current language
- SupportedLanguageTable(): get current language table
- CheckSupportedLanguage(lang_code): check if the given language code is supported
- UpdateLanguage(lang_code, cb): update language to the newly given language by language code
- SetCallback(cb): set callback function if neccessary
- GetText(id): get string text from language text table
- DisplayLanguageMap(): display current language text table by using DisplayFileTexts() function
- DisplayFileTexts(contents): asistent function to display list or dict of contents

Private member functions
- UnloadLanguageData(): clean the current loaded language table, so that a new table can be loaded
- _LoadLanguageFile : 
- _LoadLanguageIDFile :
- _LoadLanguageTableFile :
"""
Language = type("Language", (Singleton,),
                {
                    # constructor
                    "__init__" : constructor,
                    # class members
                    "__LANG_FPATH" : '.',
                    "__LANG_TABLE_FILE": None,
                    "__LANG_TABLE": {},
                    "__LANG_TEXT" : {},
                    "__LANG_ID_FILE" : "",
                    "__LANG_FILE" : "",
                    "_LANG_BASE_NAME" : "lang",
                    "__loaded" : False,
                    "__cb" : None,
                    # properties
                    "LanguageTableFile" : LanguageTableFile,
                    "LanguageFilePath" : LanguageFilePath,
                    "LanguageIdFile" : LanguageIdFile,
                    "LanguageBaseName" : LanguageBaseName,
                    "LanguageCode" : LanguageCode,
                    "LanguageName" : LanguageName,
                    # static function
                    "CreateLanguageTableFile" : _CreateLanguageTableFile,
                    # private memeber functions
                    "_LoadLanguageFile" : _LoadLanguageFile,
                    "_LoadLanguageIDFile" : _LoadLanguageIDFile,
                    "_LoadLanguageTableFile" : _LoadLanguageTableFile,
                    "UnloadLanguageData" : _UnloadLanguageData, # deprecated, it should not be called from out of class
                    # public member functions (interface)
                    "SetLanguageFileName" : _SetLanguageFileName,
                    "LoadLanguageTexts" : _LoadLanguageTexts, ## create dict for lanuge ID -> text
                    "SupportedLanguageTable" : lambda self: self.__LANG_TABLE,
                    "CheckSupportedLanguage" : lambda self, code: code in self.__LANG_TABLE,
                    "UpdateLanguage" : _UpdateLanguage,
                    "SetCallback" : _SetCallback,
                    "GetText" : _GetText,
                    "DisplayLanguageMap" : lambda self: self.DisplayFileTexts(self.__LANG_TEXT),
                    "DisplayFileTexts" : _ShowFileTexts
                })


# === main function to operate language files ===
if __name__ == '__main__':
    """if use this to test the module, use following import command
    from Singleton import Singleton
    """
    parser = argparse.ArgumentParser(prog='ClassLanguage.py', usage='%(prog)s [options]', description='Test creating class Language dynamically')
    parser.add_argument('-l', '--create-lang-table', dest='lang_list', action='append', help='language code to create language table file')
    parser.add_argument('-t', '--lang-table', dest="lang_table", action="store", default='lang_table.json', help="path-name of language table, in which the languages to be supported are defined")
    parser.add_argument('-d', '--id-file', dest='language_id_fname', action="store", default='None', help="path-name of language ids, in which the IDs are defined")
    parser.add_argument('-p', '--lang-path', dest='lang_file_path', action="store", default='.', help="path of file of language texts, for example: language.de")
    parser.add_argument('-b', '--base-name', dest='base_name', action="store", default="None", help="base name of language text file")
    parser.add_argument('-c', '--lang-code', dest='lang_code', action="store", help="language code to be used, for example: de")
    parser.add_argument('-s', '--display-lang-texts', dest='display', action="store_true", help="display all texts with current language")
    args = parser.parse_args()
    print("Arguments: [{}]".format(args))
    if args.lang_list:
        Language.CreateLanguageTableFile(args.lang_table, args.lang_list)

    ## catch LanguageTableFileNoneError if Language instance is not created.
    try:
        lang = Language(args.lang_table)
        if args.language_id_fname != 'None' and args.base_name != 'None':
            lang.SetLanguageIDFileName(args.language_id_fname).SetLanguageFileName(args.lang_file_path, args.base_name, args.lang_code).LoadLanguageTexts()
            if args.display:
                lang.DisplayLanguageMap()
        elif args.language_id_fname != 'None':
            data = lang.SetLanguageIDFileName(args.language_id_fname).LoadLanguageIDFile()
            if args.display:
                lang.DisplayFileTexts(data)
        elif args.base_name != 'None':
            data = lang.SetLanguageFileName(args.lang_file_path, args.base_name, args.lang_code).LoadLanguageFile()
            if args.display:
                lang.DisplayFileTexts(data)
        else:
            if args.display:
                print(lang.LanguageTableFile)
            
    except LanguageTableFileNoneError as err:
        print(f"{err}: Language object must be created correctly.")
        exit(-1)
    except ValueError as err:
        print(err)
    except FileExistsError as err:
        print(err)
