import sys, os
from tkinter import Toplevel
import argparse
from Common.AutoNumber import AutoIndex

class ResourceType(AutoIndex):
    ICON = ()
    IMAGE = ()
    LANGUAGE = ()
    OPTION = ()
    CONFIG = ()
    VERSION = ()

RESOURCE_PATH = ['.\\Icon', '.\\Img', '.\\Language', '.', '.', '.']
DEFAULT_BG = '#dee2e6'
DEFAULT_FG = 'black'
def Hover(widget, **kwargs):
    """Hover

    Args:
        widget (Widget): widget which is hovered
        bgcolor (str, optional): color of background. Defaults to None.
        fgcolor (str, optional): color of foreground. Defaults to 'black'.
    """
    if type(widget) == str:
        return
    bgcolor = DEFAULT_BG
    fgcolor = 'black'
    callback = None
    param = None
    for k, val in kwargs.items():
        if 'bgcolor' == k:
            bgcolor = val
        elif 'fgcolor' == k:
            fgcolor = val
        elif 'callback' == k:
            callback = val
        elif 'param' == k:
            param = val
    try:
        origbg = widget['bg']
    except:
        return
    def on_enter(event):
        if callback is not None:
            if param is None:
                callback()
            else:
                callback(param)
        if DEFAULT_FG != fgcolor:
            event.widget.config(bg=bgcolor, fg=fgcolor)
        else:
            event.widget.config(bg=bgcolor)
            
    def on_leave(event):
        if DEFAULT_FG != fgcolor:
            event.widget.config(bg=origbg, fg=DEFAULT_FG)
        else:
            event.widget.config(bg=origbg)
                    
    widget.bind("<Enter>", on_enter )
    widget.bind("<Leave>", on_leave)

def MergeTuples(src, dest)->tuple:
    """override += of tuple
    Args:
        src (tuple): source tuple, or non-tuple data which will be 
                    concate to destination tuple
        dest (tuple): destination tuple
    Returns:
        tuple: result tuple
    """
    if type(dest) != tuple:
        raise TypeError("destination must be a tuple")
    if type(src) != tuple:
        return (*dest, src)
    if len(src) == 0:
        return dest
    destlist = list(dest)
    for idx in range(0, len(dest)):
        if idx < len(src):
            if dest[idx] != src[idx]:
                destlist[idx] = src[idx]
    newdest = tuple(destlist)
    if len(src) > len(dest):
        num = len(src) - len(dest)
        newdest = newdest + src[num:]
    return newdest

def StripString(text)->str:
    """StripString
        strip all spaces and non-characters
    Args:
        text (str): string to be stripped

    Returns:
        str: result of string
    """
    retstr = ''
    b = bytes(text, encoding='ascii')
    for idx in range(0, len(text)):
        # print("[{0:x}]".format(b[idx]))
        if b[idx] >= 0x20 and b[idx]<=0x7E:
            retstr +=text[idx]
    # print (retstr)
    return retstr

## check if the package is frozen
def IsPackage():
    if getattr(sys, 'frozen', False):
        return True
    else:
        return False

def GetResource(fname:str, fpath=None, app_type=1):
    """GetResource

    Args:
        fname (str): name of file
        fpath (str, optional): path of file. Defaults to None.
        app_type (int, optional): created by auto-exe or cxfreeze. Defaults to 0.

    Raises:
        Exception: invalid file name

    Returns:
        str: path-name of file
    """
    # print(os.path.abspath(os.curdir))
    if fname is None or len(fname) == 0:
        raise Exception("Error", "File name is invalid in GetResource!")
    if getattr(sys, 'frozen', False): ## get attribute sys.frozen. if it doesn't exit, return False
        if app_type == 1: # auto-exe
            src_path = sys._MEIPASS
        else: # cx-freeze
            src_path = '.'
        if fpath is not None:
            src_path = os.path.join(src_path, fpath)
    else:
        if fpath is None:
            src_path = os.path.abspath('.')
        else:
            src_path = os.path.abspath(fpath)
    return os.path.join(src_path, fname)

def GetResourcePathName(path, srcname:str):
    """only support auto-py-exe compiler to fit the path of resource to both "frozen" state (in package) and debug state.
    path: relative path of recource if it is a string type, otherwise, it is gotten from the list of RESOURCE_PATH
    srcname: name of file
    """
    # auto-py-exe
    if type(path) == str:
        src_path = path
    else:
        src_path = RESOURCE_PATH[path.value]
    if getattr(sys, 'frozen', False):
        src_path = os.path.abspath(sys._MEIPASS, src_path)
    else:
        src_path = os.path.abspath(src_path)
    return os.path.join(src_path, srcname)

#region create popup-window and close popup-window
from typing import Callable
g_modal = True
def CreateChildWindow(parent, title, name=None, modal=True, geometry=None, center=True, ok:Callable|None=None, XClose=False):
    """CreateChildWindow
        Create popup-window
    Args:
        parent (Widget): parent widget of this popup-window
        title (str): string
        modal (bool, optional): type of window to be created. Defaults to True.
        geometry (str, optional): size and offset string just like the format in Tk. Defaults to None.
        XClose (bool, optional): if "close" button on title bar(X button) can close window. Defaults to False.

    Returns:
        Widget: created widget (popup-window)
    """
    global g_modal
    g_modal = modal
    ## remove "resize" icons on taskbar
    # parent.overrideredirect(1)
    if name is None:
        name = parent.winfo_name() + "_child"
    top = Toplevel(parent, name=name)
    if modal:
        top.grab_set()    
        # parent.wm_attributes("-disabled", True)
    top.focus_set()
    if geometry is not None:
        top.wm_geometry(geometry)
    # !!! transient command must be called after defining close window !!!
    top.transient(parent)
    if center:
        ## put new window in the center of screen
        # top.wm_geometry('300x100+959+599')
        xpos = int((parent.winfo_screenwidth() - top.winfo_width()) / 2)
        ypos = int((parent.winfo_screenheight() - top.winfo_height()) / 2)
        if geometry:
            parts = geometry.split('+')
            newgeo = f"{parts[0]}+{xpos}+{ypos}"
        else:
            newgeo =  f"+{xpos}+{ypos}"
        top.wm_geometry(newgeo) 
    top.title(title)
    top.wm_resizable(False, False)
    if ok is not None:
        Button(top, text='OK', command=lambda x=ok: on_ok(x)).pack(side='bottom', anchor='center', pady=10)
    if XClose: ## define [X] to close window
        top.protocol("WM_DELETE_WINDOW", lambda: CloseChildWindow(top))
    else:
        top.protocol("WM_DELETE_WINDOW", lambda: None)
        ## remove title bar
        # top.overrideredirect(1)
    # Wait until this window is destroyed
    def on_ok(cb):
        if cb is not None:
            cb()
        CloseChildWindow(top)
    top.wait_window(top)
    return top

def CloseChildWindow(wnd):
    """CloseChildWindow
        close popup-window which is created by CreateChildWindow()
    Args:
        wnd (Widget): popup-widow created by CreateChildWindow()
    """
    if wnd is not None:
        if g_modal:
            wnd.master.wm_attributes("-disabled", False)
        wnd.destroy()
#endregion ###

#region progress bar
def StartProgressBar(parent, task, args=None, title='Please wait...', message='Processing...', maxvalue=100, win_size='250x100', mode='indeterminate'):
    """StartProgressBar
        create and start progress bar window
    Args:
        parent (Widget): parent widget of progress bar window
        task (function, optional): long task function to be executed in background.
        args (tuple, optional): arguments of long task function. Defaults to None.
        title (str, optional): title of progress bar window. Defaults to 'Please wait...'.
        message (str, optional): message shown on progress bar window. Defaults to 'Processing...'.
        maxvalue (int, optional): maximum value of progress bar. Defaults to 100.
        win_size (str, optional): size of progress bar window. Defaults to '250x100'.
        mode (str, optional): mode of progress bar, 'indeterminate' or 'determinate'. Defaults to 'indeterminate'.

    Returns:
        Widget: progress bar window
    """
    from tkinter import Label
    from tkinter.ttk import Progressbar
    import threading
    wnd = CreateChildWindow(parent, title=title, modal=False, geometry=win_size, XClose=False)
    lbl = Label(wnd, text=message)
    lbl.pack(pady=10)
    parts = win_size.split('x')
    width = int(parts[0])
    if mode == "indeterminate":
        pbar = Progressbar(wnd, mode="indeterminate")
    else:
        pbar = Progressbar(wnd, orient='horizontal', length=int(width * 0.8), mode=mode, maximum=maxvalue)
    pbar.pack(pady=5, padx=20, fill="x")
    pbar.start(10)
    wnd.update()
    # Start background thread for the long task
    if args is None:
        threading.Thread(target=task, daemon=True).start()
    else:
        threading.Thread(target=task, args=(args[0],), daemon=True).start()
    return wnd, pbar

def StopProgressBar(parent, wnd, pbar, ms=0):
    """StopProgressBar
        stop and close progress bar window
    Args:
        wnd (Widget): progress bar window created by StartProgressBar()
        pbar (Widget): progress bar widget created by StartProgressBar()
    """
    if pbar is not None:
        pbar.stop()
    if wnd is not None:
        parent.after(ms, lambda: CloseChildWindow(wnd))
#endregion ###

def CleanWidgets(parent):
    """clean shown control elements on window"""
    widgets = parent.winfo_children()
    if len(widgets) == 0:
        return
    for w in widgets:
        if w.winfo_children():  
            widgets.extend(w.winfo_children())
    for w in widgets:
        w.grid_forget()
    parent.update() 
    parent.grid_forget()       

def CalculateCharWidth(widget, pixel_width):
    """CalculateCharWidth
        calculate the number of characters whose length is suitable for the expected number of pixels
    Args:
        widget (Widget): in which the texts are displayed
        pixel_width (int): expected width by pixel

    Returns:
        int: number of characters which fit the expected width of pixels
    """
    import tkinter.font as TkFont
    '''
    calculate the number of characters from the pixel width of a widget.
    '''
    # Get the font used in the Entry widget
    font = TkFont.Font(widget, widget.cget("font"))

    # Measure the width of a character in pixels
    char_width = font.measure("a")
    # char_width = (font.measure("a") + font.measure("_")) / 2

    # Calculate the width of characters based on pixel width
    char_count = round(pixel_width / char_width)
    print(f"Pixel with: {pixel_width}, Approximate width in characters: {char_count}")
    return char_count

import chardet
def DetectEncoding(fpath):
    with open(fpath, 'rb') as file:
        detector = chardet.universaldetector.UniversalDetector()
        for line in file:
            detector.feed(line)
            if detector.done:
                break
        detector.close()
    return detector.result['encoding']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='Util.py', usage='%(prog)s [options]', description='Test functions in Util')
    parser.add_argument('-t', '--tuple', action='store_true', default=False, help='test MergeTuples')
    parser.add_argument('-p', '--popup', action='store_true', default=False, help='test popup window - no modal')
    parser.add_argument('-b', '--button', action='store_true', default=False, help='test popup window - no modal')
    args = parser.parse_args()
    if args.tuple:
        t1 = (1, 2)
        t2 = (3, 4, 5, 6)
        print(" t1 == t2: ", t1==t2)
        print("t1 == (1, 2)", t1==(1,2))
        num = 7
        t3 = MergeTuples(t1, t2)
        t4 = MergeTuples(num, t1)
        print(t3)
        print(t4)
        t1 += t2
        print(t1)
        t5 = t1
        print(t5)
    modal_type = args.popup
    with_btn = args.button
    if with_btn:
        fct = lambda: print("Clicked OK button")
    else:
        fct = None
    from tkinter import Tk, Button
    root = Tk()
    # root.overrideredirect = True
    sub = CreateChildWindow(root, title='Test Popup', geometry='300x200', modal=modal_type, ok=fct, XClose=True)
    # Button(sub, text='Ok', width=8, command=lambda x=sub: CloseChildWindow(x)).pack(anchor='center')
    # root.wait_window(sub)
    root.mainloop()
     
    