from abc import ABC

class Parser(ABC):
    SendData = None
    @ABC.abstractmethod
    def ParseData(self, data) -> str:
        pass

    @ABC.abstractmethod
    def GetSendData(self) -> str:
        return self.SendData
    
    