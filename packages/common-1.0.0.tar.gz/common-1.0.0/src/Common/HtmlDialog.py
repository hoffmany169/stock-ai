import argparse
import re
from tkinter import *
from tkinter import messagebox
from tkhtmlview import HTMLLabel
import os, sys
sys.path.append(os.path.abspath(r'..\ProjectTools\PythonTools'))
try:
    from Common.AutoNumber import AutoNumber
except Exception as e:
    print(e)

class HtmlDialog:
    def __init__(self, parent, title='Html Dialog', size='300x200') -> None:
        self._istop = False
        if parent:
            self.parent = parent
            self.top = Toplevel(parent)
            self.top.transient(parent)
            self.top.grab_set()
        else:
            self.top = Tk()
            self._istop = True
        self.top.geometry(size)
        self.top.title(title)
        # self.top.configure(borderwidth=5, highlightthickness=5, highlightcolor='blue')
        self.Labels = []
        # self.top.iconbitmap(default=GetResource('ICON', 'SykamLogo.ico'))
        self._labelfram = Frame(self.top)
        self._labelfram.pack(fill='both', padx=10, pady=10)
        self._label = HTMLLabel(self._labelfram)
        self._label.pack(anchor='center')
        self._text = ''
        self._delimiter = '|'
        self._buttonframe = Frame(self.top)
        self._buttonframe.pack(side='bottom', anchor='center', pady=10)
        self._button = Button(self._buttonframe, text='Ok', width=6, command=self.OnOk)
        self._button.pack(side='top')
        # self._button.grid(pady=10, sticky=S)   
        self._ready = False 
        self._imgrscstr = None
        self._imgrsc = []
        self.contents = ''
            
    @property
    def IsTopTk(self):
        return self._istop

    @property
    def Text(self):
        return self._text
    
    @Text.setter
    def Text(self, text):
        self._text = text

    def SetResizable(self, w, h):
        self.top.resizable(w, h)

    def SetDelimiter(self, delim):
        self._delimiter = delim

    def GetImageResourceString(self):
        return self._imgrscstr
    
    def SetFramePad(self, padx='20', pady='10'):
        """adjust space around frame"""
        self._labelfram.config(padx=padx, pady=pady)
        
    def SetFrameIpad(self, ipadx='20', ipady='10'):
        """adjust space around frame"""
        self._labelfram.config(ipadx=ipadx, ipady=ipady)
        
    @DeprecationWarning
    def SetImage(self, imgrsc, width, height):
        self._imgrscstr = f"<img src='{imgrsc}' width='{width}' height='{height}'/>"
    
    def AddImageResource(self, imgrsc, width, height):
        self._imgrsc.append(f"<img src='{imgrsc}' width='{width}' height='{height}'/>")

    @DeprecationWarning
    def SetInfoText(self, htmltext, div=None):
        """SetInfoText

        Args:
            htmltext (str or list): string with html format to control
            displaying outlook

        Raises:
            TypeError: invalid type
        """
        # put dynamical code for icon here !!!!
        if type(htmltext) == list:
            lines = htmltext
        elif type(htmltext) == str:
            lines = htmltext.split('|')
        else:
            raise TypeError("False type of html text")
        if div:
            self._text = f'<div {div}>'
        else:
            self._text = '<div>'
        for line in range(len(lines)):
            if line == 0 and self._imgrscstr is not None:
                self._text += self._imgrscstr
            self._text += lines[line] + "<br>"
        self._text += '</div>'   
        self._ready = True     

    def AddDiv(self, htmltext, div=None, brk=False):
        """SetInfoText

        Args:
            htmltext (str or list): string with html format to control
            displaying outlook

        Raises:
            TypeError: invalid type
        """
        # put dynamical code for icon here !!!!
        lines = []
        if type(htmltext) == list:
            lines.extend(htmltext)
        elif type(htmltext) == str:
            lines.append(htmltext)
        else:
            raise TypeError("False type of html text")
        if div:
            self.contents += f'<div {div}>'
        else:
            self.contents += '<div>'
        imgrsc = re.compile('^IMG_RSC_\d+')
        for line in lines:
            if imgrsc.match(line):
                res = line.split('IMG_RSC_')
                self.contents += self._imgrsc[int(res[1])]
            else:
                self.contents += line
            if brk:
                self.AddLineBreak()
        self.contents += '</div>'  
        self._ready = True     
    
    def AddList(self, text_list, div=None, numeric=True, start=0):
        if type(text_list) != list:
            raise Exception('Exception', "Argument must be list")
        if div is not None:
            self.contents = f'<div {div}>'
        else:
            self.contents = '<div>'
            
        self.contents += '<ol>'
        for line in text_list:
            self.contents += '<li>' + line + '</li>'
        self.contents += '</ol>'
        self.contents += '</div>'  
        self._ready = True     
        
    def AddLineBreak(self):
        self.contents += '<br>'
            
    def Show(self):
        """Show
        display content of dialog, which is a list of html strings. The numbers of list corresponds to the line number
        Args:
            htmltext (list): texts to be displayed.
        """
        if not self._ready:
            messagebox.showwarning("Warning", 'Please, use SetInfoText to prepare displayed text')
            return
        # print(self.contents)    
        self._label.set_html(self.contents)
        self._label.fit_height()
        self.top.update()
        if self._istop:
            self.top.mainloop()

    def OnOk(self, *args):
        if self._istop:
            self.top.quit()
        else:
            self.top.destroy()    
## test code ###
if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='HtmlDialog', usage='%(prog)s [option]', 
                                     description='create a info dialog with HTML text string')
    parser.add_argument('-t', '--top', dest='Top', help='Dialog is a top window without parent', action='store_false', default=True)
    args = parser.parse_args()
    if args.Top:
        root = Tk()
        dlg = HtmlDialog(root, 'Compilation Info', size='300x180')
    else:
        dlg = HtmlDialog(None, 'Compilation Info', size='300x180')
    dlg.SetFramePad(pady='6')
    compileinfo = []
    compileinfo.append("Compiled ToolBox.exe successfully")
    compileinfo.append(f"Release for customer: Test")
    compileinfo.append(f"Language: English")
    compileinfo.append(f"Version: 1.0.0.0")
    dlg.AddDiv(compileinfo, div="style='font-size: 80%; text-align: left; margin-left: 80'")
    dlg.Show()
    if args.Top:
        root.mainloop()    