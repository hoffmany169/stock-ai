import argparse
import os
import smtplib, ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText
from Common.AutoNumber import AutoNumber

SMTP = {
    # 'sykam.com'     :('smtp.sykam.com',587),
    'gmail.com'     :('smtp.gmail.com', 587, 465),
    'yahoo.com'     :('smtp.mail.yahoo.com', 587, 465),
    'hotmail.com'   :('smtp-mail.outlook.com', 587),
    'live.com'      :('smtp-mail.outlook.com', 587)
    }

class ELEMENT(AutoNumber):
    Sender = ()
    Password = ()
    Receiver = ()
    Subject = ()
    Contents = ()
    Attachment = ()
class Email:
    def __init__(self, par, title=None, popup=False, withgui=True) -> None:
        self._smtp = ''
        self._withgui = withgui
        self._parent = par
        self._popup = popup
        self._top = None
        self._Variables = {}
        # states for GUI presentation
        self._ElemState = {}
        if withgui:
            self._initWithGui(title)
        else:
            self._initWithoutGui(title)
        self._defaultext = 'json'
        self._initdir = '.'
        self._initfile = None
        self._contents = None
        self._defaultcontents = ''

    def _initWithGui(self, title):
        self._SetTop(title)
        for e in ELEMENT:
            self._ElemState[e.name] = True
        # if subject is present
        self._Variables[ELEMENT.Subject.name] = StringVar(self._top)
        self._Variables[ELEMENT.Subject.name].set('Update Options.json')
        # if receiver is present
        self._Variables[ELEMENT.Receiver.name] = StringVar(self._top)
        self._Variables[ELEMENT.Receiver.name].set("peilian.yuan@sykam.com")
        self._Variables[ELEMENT.Sender.name] = StringVar(self._top)
        self._Variables[ELEMENT.Password.name] = StringVar(self._top)
        self._message = MIMEMultipart()
        # if attach file is present
        self._ElemState[ELEMENT.Attachment.name] = False
        self._Variables[ELEMENT.Attachment.name] = StringVar(self._top)
        
    def _initWithoutGui(self, title):
        # if subject is present
        self._Variables[ELEMENT.Subject.name] = 'Update Options.json'
        # if receiver is present
        self._Variables[ELEMENT.Receiver.name] = "peilian.yuan@sykam.com"
        self._Variables[ELEMENT.Sender.name] = ''
        self._Variables[ELEMENT.Password.name] = ''
        self._message = MIMEMultipart()
        self._Variables[ELEMENT.Attachment.name] = ''
        
#region properties
    @property
    def Subject(self):
        if self._withgui:
            return self._Variables[ELEMENT.Subject.name].get()
        return self._Variables[ELEMENT.Subject.name]
    
    @Subject.setter
    def Subject(self, sub):
        if self._withgui:
            self._Variables[ELEMENT.Subject.name].set(sub)
        else:
            self._Variables[ELEMENT.Subject.name] = sub
                
    @property
    def Sender(self):
        if self._withgui:
            return self._Variables[ELEMENT.Sender.name].get()
        return self._Variables[ELEMENT.Sender.name]
    
    @Sender.setter
    def Sender(self, sender):
        if self._withgui:
            self._Variables[ELEMENT.Sender.name].set(sender)
        else:
            self._Variables[ELEMENT.Sender.name] = sender
    
    @property
    def Receiver(self):
        if self._withgui:
            return self._Variables[ELEMENT.Receiver.name].get()
        return self._Variables[ELEMENT.Receiver.name]
    
    @Receiver.setter
    def Receiver(self, rcv):
        if self._withgui:
            self._Variables[ELEMENT.Receiver.name].set(rcv)
        else:
            self._Variables[ELEMENT.Receiver.name] = rcv
        
    @property
    def Password(self):
        if self._withgui:
            return self._Variables[ELEMENT.Password.name].get()
        return self._Variables[ELEMENT.Password.name]
    
    @Password.setter
    def Password(self, pwd):
        if self._withgui:
            self._Variables[ELEMENT.Password.name].set(pwd)
        else:
            self._Variables[ELEMENT.Password.name] = pwd
        
    @property
    def AttachFile(self):
        if self._withgui:
            return self._Variables[ELEMENT.Attachment.name].get()
        return self._Variables[ELEMENT.Attachment.name]
    
    @AttachFile.setter
    def AttachFile(self, attch):
        if self._withgui:
            self._Variables[ELEMENT.Attachment.name].set(attch)
        else:
            self._Variables[ELEMENT.Attachment.name] = attch
    
    @property
    def DefaultFileExtension(self):
        return self._defaultext
    
    @DefaultFileExtension.setter
    def DefalutFileExtension(self, ext):
        self._defaultext = ext
#endregion
    
    def _SetTop(self, title):
        if self._parent is None:
            self._top = Tk()
            self._top.resizable(False, False)
            if title is None:
                self._top.title('Send email')
            else:
                self._top.title(title)
        else:
            if self._popup:
                self._parent.attributes('-disabled', True)
                self._top = Toplevel(self._parent)
                self._top.transient(self._parent)
                self._top.focus_set()
                # self._top.grab_set()
                if title is None:
                    self._top.wm_title('Send email')
                else:
                    self._top.wm_title(title)
            else:
                self._top = self._parent
        
    def CreateGui(self):
        if not self._withgui:
            return
        frm = Frame(self._top)
        frm.grid(row=0, columnspan=2, padx=10, pady=10, sticky=NSEW)
        row_idx = 0
        if self._ElemState[ELEMENT.Sender.name]:
            Label(frm, text='Sender email:', anchor=W, width=12).grid(row=row_idx, column=0, padx=5, pady=5)
            Entry(frm, name='sender', textvariable=self._Variables[ELEMENT.Sender.name], width=26).grid(row=row_idx, column=1, padx=5, pady=5, sticky=W)
            row_idx += 1
        if self._ElemState[ELEMENT.Password.name]:
            Label(frm, text='Password:', anchor=W, width=12).grid(row=row_idx, column=0, padx=5, pady=5)
            Entry(frm, name='password', textvariable=self._Variables[ELEMENT.Password.name], show='*', width=26).grid(row=row_idx, column=1, padx=5, pady=5, sticky=W)
            row_idx += 1
        if self._ElemState[ELEMENT.Receiver.name]:
            Label(frm, text='Receiver email:', anchor=W, width=12).grid(row=row_idx, column=0, padx=5, pady=5)
            Entry(frm, name='receiver', textvariable=self._Variables[ELEMENT.Receiver.name], width=26).grid(row=row_idx, column=1, padx=5, pady=5, sticky=W)
            row_idx += 1
        if self._ElemState[ELEMENT.Subject.name]:
            Label(frm, text='Subject:', anchor=W, width=12).grid(row=row_idx, column=0, padx=5, pady=5)
            Entry(frm, name='subject', textvariable=self._Variables[ELEMENT.Subject.name], width=26).grid(row=row_idx, column=1, padx=5, pady=5, sticky=W)
            row_idx += 1
        if self._ElemState[ELEMENT.Contents.name]: # add scrolled text
            Label(frm, text='Contents:', anchor=W, width=12).grid(row=row_idx, column=0, padx=5, pady=5)
            self._contents = ScrolledText(frm, wrap=WORD, width=20, height=10)
            self._contents.grid(row=row_idx, column=1, padx=5, pady=5, sticky=W)
            if len(self._defaultcontents) > 0:
                self._contents.insert(INSERT, self._defaultcontents)
            row_idx += 1
        
        if self._ElemState[ELEMENT.Attachment.name]: # add field for attaching file
            Button(frm, text='Attachment', width=10, command=self._OnAttach).grid(row=row_idx, column=0, padx=5, pady=5)
            Entry(frm, textvariable=self._Variables[ELEMENT.Attachment.name], width=26).grid(row=row_idx, column=1, padx=5, pady=5)
            
        btn_frm = Frame(self._top)
        btn_frm.grid(row=1, columnspan=2, padx=10, pady=10, sticky=NS)
        # btn_frm.grid_columnconfigure(1, weight=1)
        Button(btn_frm, text='Send', width=8, justify=CENTER, command=self._OnSend).grid(row=0, column=0, padx=5)
        Button(btn_frm, text='Close', width=8, justify=CENTER, command=self._OnClose).grid(row=0, column=1, padx=5)
        self._top.protocol("WM_DELETE_WINDOW", self._OnClose)
        
        if self._parent is None:
            self._top.mainloop()
    
    def DisableElement(self, *args):
        for e in args:
            self._ElemState[e.name] = False
        
    def EnableElement(self, *args):
        for e in args:
            self._ElemState[e.name] = True

    def AddContents(self, text):
        if self._contents is None:
            self._defaultcontents = text
        else:
            self._contents.insert(INSERT, text)

    def _OnAttach(self):
        self.AttachFile = (filedialog.askopenfilename(defaultextension=self._defaultext, initialdir=self._initdir, initialfile=self._initfile))
            
    def _CreateMessage(self):
        if len(self.Subject) == 0:
            messagebox.showwarning("Waring", "Subject is empty!")
        if len(self.Sender) == 0 or len(self.Receiver) == 0:
            messagebox.showerror("Error", "Address of both sender and receiver must be valid!")
            return
        if not self.Sender.find('@'):
            messagebox.showerror("Error", "Address of sender must be valid!")
            return
        if not self.Receiver.find('@'):
            messagebox.showerror("Error", "Address of receiver must be valid!")
            return
        if len(self.Password) == 0:
            messagebox.showerror("Error", "Password of sender must be valid!")
            return
        self._message["Subject"] = self.Subject
        self._message["From"] = self.Sender
        self._message["To"] = self.Receiver
        if self._ElemState[ELEMENT.Contents.name]:
            self._message.attach(MIMEText(self._contents.get("1.0", END), "plain"))
        else:
            if len(self._defaultcontents) > 0:
                self._message.attach(MIMEText(self._defaultcontents, "plain"))
        self._AddAttachment()
    
    def _OnSend(self):
        self._CreateMessage()
        text = self._message.as_string()
        sender = self.Sender
        part2 = sender.split('@')
        self._smtp = part2[1]                
        # Log in to server using secure context and send email
        self._SendEmailBySmtp(text)
        self._OnClose()
    
    def _AddAttachment(self):
        if len(self.AttachFile) > 0 and os.path.exists(self.AttachFile):
            with open(self.AttachFile) as f:
                # Add file as application/octedt-stream: Eamil client can usually download this automatically as attachment
                attachment = MIMEBase("application", "octet-stream")
                attachment.set_payload(f.read())
            #encode file
            encoders.encode_base64(attachment)
            # add header as key/value pair to attachment part
            bn = os.path.basename(self.AttachFile)
            attachment.add_header("Content-Disposition", f"Attachment; filename={bn}",)
            self._message.attach(attachment)
        else:
            print(f"Invalid attachment: {self.AttachFile}")
    
    def _SendEmailBySmtp(self, text):
        context = ssl.create_default_context()
        try:
            with smtplib.SMTP(SMTP[self._smtp][0], SMTP[self._smtp][1]) as server:
                server.ehlo()
                server.starttls(context=context) 
                server.ehlo()
                print(f"Sending: from [{self.Sender}], to [{self.Receiver}]")
                (code, resp) = server.login(self.Sender, self.Password)
                print(f"code: {code}, response: {resp}")
                server.sendmail(self.Sender, self.Receiver, text)
        except Exception as e:
            messagebox.showerror("Exception", e)
        else:
            messagebox.showinfo("Sent Email", "Email was sent successfully!")
        
    def _SendEmailBySSL(self, text):
        context = ssl.create_default_context()
        try:
            with smtplib.SMTP_SSL(SMTP[self._smtp][0], SMTP[self._smtp][2], context=context) as server:
                print(f"Sending: from [{self.Sender}], to [{self.Receiver}]")
                (code, resp) = server.login(self.Sender, self.Password)
                print(f"code: {code}, response: {resp}")
                server.send_message(text)
        except Exception as e:
            messagebox.showerror("Exception", e)
        finally:
            messagebox.showinfo("Sent Email", "Email was sent successfully!")
                                   
    def SendEmail(self, ssl=False):
        if self._withgui:
            return
        self._CreateMessage()
        text = self._message.as_string()
        sender = self.Sender
        part2 = sender.split('@')
        self._smtp = part2[1]                
        # Log in to server using secure context and send email
        self._SendEmailBySmtp(text)
    
    def _OnClose(self):
        if self._popup:
            self._parent.attributes("-disabled", False)
        self._top.destroy()
        
if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='Email.py', usage='%(prog)s [options]', description='Send email')
    parser.add_argument('-u', '--gui', action='store_true', default=False, help="start program with GUI version")
    parser.add_argument('-s', '--subject', dest='subject', help="Email subject", default=None )
    parser.add_argument('-f', '--from', dest='sender', help="Email address of sender", default=None )
    parser.add_argument('-t', '--to', dest='receiver', help='Email address of receiver', default=None)
    parser.add_argument('-p', '--password', dest='pwd', help='Password of sender', default=None)
    parser.add_argument('-a', '--attach', dest='attach', help="Name of attached file", default=None)
    args = parser.parse_args()
    
    if args.gui:
        print("Starting program with GUI")
        my_email = Email()
        my_email.CreateGui(None, body=True)
    else:
        my_email = Email()
        if args.subject:
            my_email.Subject = args.subject
        if args.sender:
            my_email.Sender = args.sender
        else:
            messagebox.showerror("Error", "Address of sender must be valid!")
        if args.receiver:
            my_email.Receiver = args.receiver
        else:
            messagebox.showerror("Error", "Address of receiver must be valid!")
        if args.attach:
            my_email.AttachFile = args.attach
        if args.password:
            my_email.Password = args.password
        my_email.SendEmail()
        
        