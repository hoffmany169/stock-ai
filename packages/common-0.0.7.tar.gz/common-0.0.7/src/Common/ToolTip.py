from tkinter import *
from Common.Util import Hover

class ToolTip(object):
    def __init__(self, widget, pos=S) -> None:
        self.widget = widget
        self.tip_window = None
        self.pos = pos
        
    def show_tip(self, text):
        if not self.widget:
            return
        if type(text) == str:
            tip_text = text
        else: # function
            tip_text = text()
        if len(tip_text) == 0:
            return
        x, y, _cx, _cy = self.widget.bbox("insert")
        x = x + self.widget.winfo_rootx() + 25
        if self.pos == N:
            y = y + _cy - 25
        else:
            y = y + _cy + self.widget.winfo_rooty() + 25
        self.tip_window = tw = Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry("+%d+%d" % (x, y))
        
        label = Label(tw, text=tip_text, justify=LEFT,
                      bg="#ffffe0", relief=SOLID, borderwidth=1,
                      font=("tahoma", "8", "normal"))
        label.pack(ipadx=1)
        
    def hide_tip(self):
        tw = self.tip_window
        self.tip_window = None
        if tw:
            tw.destroy()
        self.widget.update()
            
            
# ======== use tooltip =========
def create_tooltip(widget, text, pos=S, hover=False):
    if widget == None:
        return
    tooltip = ToolTip(widget, pos)
    # def on_focus_in(event):
    #     tooltip.show_tip(text)
    # def on_focus_out(event):
    #     tooltip.hide_tip()
    def on_enter(event):
        tooltip.show_tip(text)
        if hover:
            Hover(widget)
    def on_leave(event):
        tooltip.hide_tip()
    # widget.bind('<FocusIn>', on_focus_in)
    # widget.bind('<FocusOut>', on_focus_out)
    widget.bind('<Enter>', on_enter)
    widget.bind('<Leave>', on_leave)

########## test ###########
if __name__ == '__main__':
    mainwin = Tk()
    mainwin.geometry('100x50')
    create_tooltip(mainwin, 'This is test for tool tip')
    mainwin.mainloop()