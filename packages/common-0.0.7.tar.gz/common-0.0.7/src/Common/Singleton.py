
class Singleton(object):
    """ Implement Singleton by class
    """
    # class static variables 
    _instance = None
    def __new__(cls, *args, **kwargs):
        '''create Singleton instance. if existed, return it
        '''
        if not cls._instance:
            ## original: cls._instance = object.__new__(cls, *args, **kwargs), suitable for implementation
            cls._instance = object.__new__(cls)
        return cls._instance
    
    def __del__(self):
        '''deconstructor
        '''
        type(self)._instance = None
        print("Singleton destructor")

    @classmethod
    def created(cls):
        '''static class method created
        used to check if instance is already created in the child class
        '''
        return (cls._instance != None)

    @classmethod
    def destroy(cls):
        '''destroy instance by static method
        '''
        if cls._instance:
            del cls._instance
            cls._instance = None
        print("Singleton destoried")

def singleton(cls):
    """ Implement Singleton by closure
    """
    instances = {}
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return get_instance