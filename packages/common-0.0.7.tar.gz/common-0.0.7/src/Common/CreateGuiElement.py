import sys, os
sys.path.append(r'.')
from tkinter import Tk, Label, Entry, Button, Menu, Menubutton, StringVar
from tkinter.ttk import Combobox
from Common.Util import Hover
from Common.ClassLanguage import Language


class CreateGuiElement:
    def __init__(self, parent):
        self._parent = parent
        self._control_texts = {}
        self._entries = {}
        self._menu_texts = {}

    def CreateEntry(self, row, text, entry_name=None, col_span_list=[1, 1], **kargs):
        '''
        CreateEntry
        create an entry on the page like: Name: TEXT_EDITOR_FIELD
        param[row]: row number
        param[text]: label text
        param[entry_name]: mame of Entry control, default name is entry_ROW
        param[col_span_list]: property colume-span for the two columes
        param[**kargs]: other properties for label and Entry:
                        anchor, width_0, padx_0, pady_0 for label; padx_1, pady_1, with_1 for entry
        '''
        _anchor = 'e'
        _width_0 = None
        _padx_0 = 10
        _pady_0 = 10
        _padx_1 = 10
        _pady_1 = 10
        _width_1 = None
        if len(kargs) > 0:
            for k, v in kargs.items():
                if 'width_0' == k:
                    _width_0 = v
                elif 'padx_0' == k:
                    _padx_0 = v
                elif 'pady_0' == k:
                    _pady_0 = v
                elif 'anchor' == k:
                    _anchor = v
                elif 'width_1' == k:
                    _width_1 = v
                elif 'padx_1' == k:
                    _padx_1 = v
                elif 'pady_1' == k:
                    _pady_1 = v
        lbl = Label(self._parent, text=text, anchor=_anchor, width=_width_0)
        lbl.grid(row=row, column=0, columnspan=col_span_list[0], padx=_padx_0, pady=_pady_0)
        self._control_texts[text] = lbl
        if entry_name is None:
            name = f'entry_{row}'
        else:
            name = entry_name
        if text in self._entries:
            raise ValueError(f"Entry Name [{text}] exists already!")
        entry = Entry(self._parent, name=name)
        entry.grid(row=row, column=1, columnspan=col_span_list[1], padx=_padx_1, pady=_pady_1)
        self._entries[text] = entry
        if _width_0:
            lbl.config(width=_width_0)
        if _width_1:
            entry.config(width=_width_1)
        return self

    def CreateComBoxEntry(self, row, text, entry_name=None, col_span_list=[1, 1], **kargs):
        '''
        CreateComBoxEntry
        create an entry on the page like: Name: TEXT_COMBOBOX
        param[row]: row number
        param[text]: label text
        param[entry_name]: mame of Entry control, default name is entry_ROW
        param[col_span_list]: property colume-span for the two columes
        param[**kargs]: other properties for label and Entry:
                        anchor, width_0, padx_0, pady_0 for label; padx_1, pady_1, with_1 for entry
        '''
        _anchor = 'e'
        _width_0 = None
        _padx_0 = 10
        _pady_0 = 10
        _padx_1 = 10
        _pady_1 = 10
        _width_1 = None
        if len(kargs) > 0:
            for k, v in kargs.items():
                if 'width_0' == k:
                    _width_0 = v
                elif 'padx_0' == k:
                    _padx_0 = v
                elif 'pady_0' == k:
                    _pady_0 = v
                elif 'anchor' == k:
                    _anchor = v
                elif 'width_1' == k:
                    _width_1 = v
                elif 'padx_1' == k:
                    _padx_1 = v
                elif 'pady_1' == k:
                    _pady_1 = v
        lbl = Label(self._parent, text=text, anchor=_anchor, width=_width_0)
        lbl.grid(row=row, column=0, columnspan=col_span_list[0], padx=_padx_0, pady=_pady_0)
        self._control_texts[text] = lbl
        if entry_name is None:
            name = f'entry_{row}'
        else:
            name = entry_name
        if text in self._entries:
            raise ValueError(f"Entry Name [{text}] exists already!")
        cmb = Combobox()


    def CreateMenuButton(self, row, col, texts:dict, cmd_list, hover=True, **kargs):
        '''
        CreateMenuButton
        create Menubutton (add_command) or check-button (add_checkbutton) - todo
        param[row]: row number
        param[col]: column number
        param[text]: text on the button
        param[sub_text_list]: texts on button menus
        param[cmd_list]: list of commands for button menus
        param[hover]: activate hover for button menus, default: True
        param[**kargs]: other properties for label and Entry: width, padx, pady
        '''
        if texts is None:
            raise ValueError("No texts for menu button")
        if len(cmd_list) == 0:
            raise ValueError("List of commands are empty!")
        text = list(texts)[0]
        sub_text_list = texts.get(text)
        if len(sub_text_list) != len(cmd_list):
            raise ValueError("number of commands does not match that of sub-menus!")
        _width = 10
        _padx = 10
        _pady = 10
        if len(kargs) > 0:
            for k, v in kargs.items():
                if 'width' == k:
                    _width = v
                elif 'padx' == k:
                    _padx = v
                elif 'pady' == k:
                    _pady = v
        btn = Menubutton(self._parent, text=text, relief='raised', width=_width)
        btn.grid(row=row, column=col, padx=_padx, pady=_pady)
        self._menu_texts[text] = btn
        btn.menu = Menu(btn, tearoff=0)
        btn["menu"] = btn.menu
        for idx, sub_text in enumerate(sub_text_list):
            btn.menu.add_command(label=sub_text, command=cmd_list[idx] if cmd_list and idx < len(cmd_list) else None)
            self._menu_texts[sub_text] = btn.menu
            if hover:
                Hover(btn.menu)
        return self

    def CreateButton(self, row:int, col:int, text:str, cmd, name=None, hover=True, **kargs):
        '''
        CreateEntry
        create an entry on the page like: Name: TEXT_EDITOR_FIELD
        param[row]: row number
        param[col]: column number
        param[text]: button text
        param[cmd]: callback function for button
        param[name]: name of button, default name: button_ROW_COLUMN
        param[hover]: activate hover for button menus, default: True
        param[**kargs]: other properties for label and Entry:
                        width, padx, pady
        '''
        _width = 8
        _padx = 10
        _pady = 10
        _columnspan = 1
        while len(kargs) > 0:
            k, v = kargs.popitem()
            if 'width' == k:
                _width = v
            elif 'padx' == k:
                _padx = v
            elif 'pady' == k:
                _pady = v
            elif 'columnspan' == k:
                _columnspan = v
        btn_name = f'button_{row}_{col}' if name is None else name
        btn = Button(self._parent, name=btn_name, text=text, width=_width, command=cmd)
        btn.grid(row=row, column=col, columnspan=_columnspan, padx=_padx, pady=_pady)
        if text == '...':
            text = 'select'
        if text in self._control_texts:
            print(f"Entry Name [{text}] exists already!")
            entry_text = f"{text}_1"
        else:
            entry_text = text
        self._control_texts[entry_text] = btn
        if len(kargs) > 0:
            btn.config(kargs)
        if hover:
            Hover(btn)
        return self

    def CreateMenu(self, menu_texts:dict, cmd_list=None) -> Menu:
        '''
        CreateMenu
        param[menu_texts]: list[dict]
        param[cmds]: dict
        return Menu
        '''
        ## database menu
        menubar = Menu(self._parent)
        self._parent['menu'] = menubar
        idx0 = 0
        for menu_text, sub_text_list in menu_texts.items():
            newmenu = Menu(menubar, tearoff=False) # remove the dashed line
            for idx1, text in enumerate(sub_text_list):
                if text == 'SEPARATOR': 
                    newmenu.add_separator()
                else:
                    newmenu.add_command(label=text, command=cmd_list[idx0][idx1])
                    self._menu_texts[text] = newmenu
            menubar.add_cascade(label=menu_text, menu=newmenu)
            self._menu_texts[menu_text] = menubar
            idx0 += 1
        menubar.update()
        return self

    def GetControl(self, name=None, text=None):
        '''
        GetControl
        get control, that is label, entry, menu, button and menu button
        '''
        if name is not None:
            return self._parent.nametowidget(name)
        elif text is not None:
            if text in self._control_texts:
                return self._control_texts[text]
            elif text in self._menu_texts:
                return self._menu_texts[text]
        return None

    def GetEntryText(self, name=None, text=None):
        '''
        GetEntryText
        return text in the text field
        '''
        if name is not None:
            control = self.GetControl(name=name)
            return control.get().strip()
        elif text is not None:
            return self._entries[text].get().strip()

    def SetEntryText(self, new_text, name=None, text=None):
        '''
        SetEntryText
        set text in the text field to new_text
        param[entry_id] line index if it is an int, or entry name if it is a string
        '''
        if name is None and text is None:
            raise ValueError("Error: one of text and name of entry must be specified!")

        if name:
            control = self.GetControl(name=name)
            control.insert(0, new_text)
        elif text:
            self._entries[text].insert(0, new_text)

    def UpdateControlText(self):
        pass


class CreateMultiLanguageGuiElement(CreateGuiElement):
    def __init__(self, parent, language:Language):
        super().__init__(parent)
        self._lang = language

    def CreateEntry(self, row, text_id, entry_name=None, col_span_list=[1, 1], **kargs):
        text = self._lang.GetText(text_id)
        super().CreateEntry(row, text=text, entry_name=entry_name, col_span_list=col_span_list, kargs=kargs)
        label = self._control_texts.pop(text)
        self._control_texts[text_id] = label
        entry = self._entries.pop(self._lang.GetText(text_id))
        ## change key from text to text id
        self._entries[text_id] = entry
        return self

    def CreateButton(self, row, col, text_id, cmd, name=None, hover=True, **kargs):
        text = self._lang.GetText(text_id)
        super().CreateButton(row, col, text, cmd, name, hover, **kargs)
        btn = self._control_texts.pop(text)
        self._control_texts[text_id] = btn
        return self

    def CreateMenuButton(self, row, col, text_ids:dict, cmd_list, hover=True, **kargs):
        '''
        CreateMenuButton
        create Menubutton (add_command) or check-button (add_checkbutton) - todo
        param[row]: row number
        param[col]: column number
        param[text]: text on the button
        param[sub_text_list]: texts on button menus
        param[cmd_list]: list of commands for button menus
        param[hover]: activate hover for button menus, default: True
        param[**kargs]: other properties for label and Entry: width, padx, pady
        '''
        if text_ids is None:
            raise ValueError("No texts for menu button")
        if len(cmd_list) == 0:
            raise ValueError("List of commands are empty!")
        btn_text_id = list(text_ids)[0]
        sub_text_ids = text_ids.get(btn_text_id)
        if len(sub_text_ids) != len(cmd_list):
            raise ValueError("number of commands does not match that of sub-menus!")
        _width = 10
        _padx = 10
        _pady = 10
        if len(kargs) > 0:
            for k, v in kargs.items():
                if 'width' == k:
                    _width = v
                elif 'padx' == k:
                    _padx = v
                elif 'pady' == k:
                    _pady = v
        text = self._lang.GetText(btn_text_id)
        btn = Menubutton(self._parent, text=text, relief='raised', width=_width)
        btn.grid(row=row, column=col, padx=_padx, pady=_pady)
        self._menu_texts[btn_text_id] = (btn, text)
        btn.menu = Menu(btn, tearoff=0)
        btn["menu"] = btn.menu
        for idx, sub_text_id in enumerate(sub_text_ids):
            sub_text = self._lang.GetText(sub_text_id)
            btn.menu.add_command(label=sub_text, command=cmd_list[idx] if cmd_list and idx < len(cmd_list) else None)
            self._menu_texts[sub_text_id] = (btn.menu, sub_text)
            if hover:
                Hover(btn.menu)
        return self

    def CreateMenu(self, menu_text_ids:dict, cmd_list=None):
        menubar = Menu(self._parent)
        self._parent['menu'] = menubar
        idx0 = 0
        for menu_text_id, sub_text_ids in menu_text_ids.items():
            newmenu = Menu(menubar, tearoff=False) # remove the dashed line
            for idx1, text_id in enumerate(sub_text_ids):
                if text_id == 'SEPARATOR': 
                    newmenu.add_separator()
                else:
                    sub_menu_text = self._lang.GetText(text_id)
                    newmenu.add_command(label=sub_menu_text, command=cmd_list[idx0][idx1])
                    self._menu_texts[text_id] = newmenu
            menu_text = self._lang.GetText(menu_text_id)
            menubar.add_cascade(label=menu_text, menu=newmenu)
            self._menu_texts[menu_text_id] = menubar
            idx0 += 1
        menubar.update()
        return self
    
    def UpdateControlText(self):
        '''
        UpdateControlText
        update texts of labels and buttons if they are changed
        '''
        if len(self._control_texts) > 0:
            ## update label texts
            for id, widget in self._control_texts.items():
                widget['text'] = (self._lang.GetText(id))
        if len(self._menu_texts) > 0:
            for id, data in self._menu_texts:
                label_text = self._lang.GetText(id)
                data[0].entryconfig(data[1], label=label_text)
                self._menu_texts[id] = (data[0], label_text)           

## function for tests
def on_test():
    print("This is the test button, change entry text")
    global creator
    creator.SetEntryText('Test Entry', text='Entry')

if __name__ == "__main__":
    global creator
    root = Tk()
    root.title = "test creating GUI"
    root.geometry('240x140')
    creator = CreateGuiElement(root)
    creator.CreateEntry(0, 'Entry').CreateButton(1, 0, 'Test', cmd=on_test).CreateMenuButton(1, 1, {"MButton": ["Option 1", "Option 2"]}, [on_test, None]).CreateMenu({"Test Menu":["Menu 1", "Menu 2"]}, [[on_test, None]])

    root.mainloop()